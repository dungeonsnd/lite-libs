#include "openssl/rsa.h"
#include "openssl/sha.h"
#include "openssl/x509.h"

#include <string.h>

#define LINE_SUM 15

int Enc()
{
    /*
    ���� padding ���������ݳ��ȵ�Ҫ��
    ˽Կ���ܣ�
    RSA_PKCS1_PADDING RSA_size-11
    RSA_NO_PADDING RSA_size-0
    RSA_X931_PADDING RSA_size-2
    ��Կ����
    RSA_PKCS1_PADDING RSA_size-11
    RSA_SSLV23_PADDING RSA_size-11
    RSA_X931_PADDING RSA_size-2
    RSA_NO_PADDING RSA_size-0
    RSA_PKCS1_OAEP_PADDING RSA_size-2 * SHA_DIGEST_LENGTH-2
    */

    RSA *r;
    int bits=2048,ret,len,flen,padding,i;
    unsigned long e=RSA_3;
    BIGNUM *bne;
    unsigned char *key,*p;
    BIO *b;
    unsigned char from[500],to[500],out[500];
    bne=BN_new();
    ret=BN_set_word(bne,e);
    r=RSA_new();
    ret=RSA_generate_key_ex(r,bits,bne,NULL);
    if(ret!=1)
    {
        printf("\nRSA_generate_key_ex err!\n");
        return -1;
    }


    /* ˽Կi2d */
    b=BIO_new(BIO_s_mem());
    ret=i2d_RSAPrivateKey_bio(b,r);
    key=(unsigned char *)(malloc(1024));
    len=BIO_read(b,key,1024);
    BIO_free(b);
    b=BIO_new_file("rsa.key","w");
    ret=i2d_RSAPrivateKey_bio(b,r);
    BIO_free(b);

    /* ˽Կd2i */
    /* ��Կi2d */
    /* ��Կd2i */
    /* ˽Կ���� */
    flen=RSA_size(r);
    printf("\nplease select private enc padding : \n");
    printf("1.RSA_PKCS1_PADDING\n");
    printf("3.RSA_NO_PADDING\n");
    printf("5.RSA_X931_PADDING\n");
    scanf("%d",&padding);
    if(padding==RSA_PKCS1_PADDING)
        flen-=11;
    else if(padding==RSA_X931_PADDING)
        flen-=2;
    else if(padding==RSA_NO_PADDING)
        flen=flen;
    else
    {
        printf("\nrsa not surport !\n");
        return -1;
    }
    printf("\nfrom----\n");
    for(i=0;i<flen;i++)
    {
        memset(&from[i],i,1);
        printf("%02x,",from[i]);
        if (i%LINE_SUM==LINE_SUM-1) printf("\n");
    }
    len=RSA_private_encrypt(flen,from,to,r,padding);
    if(len<=0)
    {
        printf("RSA_private_encrypt err!\n");
        return -1;
    }
    printf("\nto----\n");
    for(i=0;i<flen;i++)
    {
        printf("%02x,",to[i]);
        if (i%LINE_SUM==LINE_SUM-1) printf("\n");
    }
    len=RSA_public_decrypt(len,to,out,r,padding);
    if(len<=0)
    {
        printf("RSA_public_decrypt err!\n");
        return -1;
    }
    printf("\nout----\n");
    for(i=0;i<flen;i++)
    {
        printf("%02x,",out[i]);
        if (i%LINE_SUM==LINE_SUM-1) printf("\n");
    }
    if(memcmp(from,out,flen))
    {
        printf("\nerr!\n");
        return -1;
    }


    /* */
    printf("\nplease select public enc padding : \n");
    printf("1.RSA_PKCS1_PADDING\n");
    printf("2.RSA_SSLV23_PADDING\n");
    printf("3.RSA_NO_PADDING\n");
    printf("4.RSA_PKCS1_OAEP_PADDING\n");
    scanf("%d",&padding);
    flen=RSA_size(r);
    if(padding==RSA_PKCS1_PADDING)
        flen-=11;
    else if(padding==RSA_SSLV23_PADDING)
        flen-=11;
    else if(padding==RSA_X931_PADDING)
        flen-=2;
    else if(padding==RSA_NO_PADDING)
        flen=flen;
    else if(padding==RSA_PKCS1_OAEP_PADDING)
        flen=flen-2 * SHA_DIGEST_LENGTH-2 ;
    else
    {
        printf("rsa not surport !\n");
        return -1;
    }
    printf("\nfrom----\n");
    for(i=0;i<flen;i++)
    {
        memset(&from[i],i+1,1);
        printf("%02x,",from[i]);
        if (i%LINE_SUM==LINE_SUM-1) printf("\n");
    }
    len=RSA_public_encrypt(flen,from,to,r,padding);
    if(len<=0)
    {
        printf("RSA_public_encrypt err!\n");
        return -1;
    }
    printf("\nto----\n");
    for(i=0;i<flen;i++)
    {
        printf("%02x,",to[i]);
        if (i%LINE_SUM==LINE_SUM-1) printf("\n");
    }
    len=RSA_private_decrypt(len,to,out,r,padding);
    if(len<=0)
    {
        printf("RSA_private_decrypt err!\n");
        return -1;
    }
    printf("\nout----\n");
    for(i=0;i<flen;i++)
    {
        printf("%02x,",out[i]);
        if (i%LINE_SUM==LINE_SUM-1) printf("\n");
    }
    if(memcmp(from,out,flen))
    {
        printf("\nerr!\n");
        return -1;
    }
    printf("\ntest ok!\n");
    RSA_free(r);
    return 0;
}

int GenKey()
{
    RSA *r;
    int bits=2048,ret;
    unsigned long e=RSA_3;
    BIGNUM *bne;
    printf("----------------------------------------\n");
    bne=BN_new();
    ret=BN_set_word(bne,e);
    r=RSA_new();
    ret=RSA_generate_key_ex(r,bits,bne,NULL);
    if(ret!=1)
    {
        printf("RSA_generate_key_ex err!\n");
        return -1;
    }
    RSA_print_fp(stdout,r,5);
    printf("----------------------------------------\n");
    RSA_free(r);
}

int Sign()
{
    int ret;
    RSA *r;
    int i,bits=1024,datalen,alg,nid;
    unsigned int signlen;
    unsigned long e=RSA_3;
    BIGNUM *bne;
    unsigned char data[100],signret[200];
    bne=BN_new();
    ret=BN_set_word(bne,e);
    r=RSA_new();
    ret=RSA_generate_key_ex(r,bits,bne,NULL);
    if(ret!=1)
    {
        printf("RSA_generate_key_ex err!\n");
        return -1;
    }

    printf("\data----\n");
    for(i=0;i<100;i++)
    {
        memset(&data[i],i+1,1);
        printf("%02x,",data[i]);
        if (i%LINE_SUM==LINE_SUM-1) printf("\n");
    }

    printf("\nplease select digest alg: \n");
    printf("1.NID_md5\n");
    printf("2.NID_sha\n");
    printf("3.NID_sha1\n");
    printf("4.NID_md5_sha1\n");
    scanf("%d",&alg);
    if(alg==1)
    {
        datalen=55;
        nid=NID_md5;
    }
    else if(alg==2)
    {
        datalen=55;
        nid=NID_sha;
    }
    else if(alg==3)
    {
        datalen=55;
        nid=NID_sha1;
    }
    else if(alg==4)
    {
        datalen=36;
        nid=NID_md5_sha1;
    }
    ret=RSA_sign(nid,data,datalen,signret,&signlen,r);
    if(ret!=1)
    {
        printf("RSA_sign err!\n");
        RSA_free(r);
        return -1;
    }
    //memset(&data[2],2+1+10,1);
    ret=RSA_verify(nid,data,datalen,signret,signlen,r);
    if(ret!=1)
    {
        printf("RSA_verify err!\n");
        RSA_free(r);
        return -1;
    }
    RSA_free(r);
    printf("test ok!\n");
    return 0;
}

int main()
{
    GenKey();
    //Enc();
    //Sign();

    char ch;
    printf("press anykey to exit...\n");
    scanf("%c",&ch);
    scanf("%c",&ch);
	return 0;
}
