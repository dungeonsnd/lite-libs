#!/bin/bash

g++ -Wall ssl_client.cpp -o client -lssl