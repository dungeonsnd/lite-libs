#!/bin/bash

g++ -Wall ssl_server.cpp -o server -lssl